#!/usr/bin/env python
# coding: utf-8

# Copyright (c) Microsoft. All rights reserved.
# Licensed under the MIT license. See LICENSE.md file in the project root for full license information.
"""
This is an example of how to use a push audio stream to recognize speech from a custom audio
source.
"""

import time
import threading
import wave

try:
    import azure.cognitiveservices.speech as speechsdk
except ImportError:
    print("""
    Importing the Speech SDK for Python failed.
    Refer to
    https://docs.microsoft.com/azure/cognitive-services/speech-service/quickstart-python for
    installation instructions.
    """)
    import sys
    sys.exit(1)


# Set up the subscription info for the Speech Service:
# Replace with your own subscription key and service region (e.g., "westus").
speech_key, service_region = "YourSubscriptionKey", "YourServiceRegion"

# Specify the path to an audio file containing speech (mono WAV / PCM with a sampling rate of 16
# kHz).
input_filename = "YourAudioFile"


def send_voice_frame(stream):
    print('ENTER send_voice_frame')
    # The number of bytes to push per buffer
    n_bytes = 3200
    wav_fh = wave.open(input_filename)

    # start pushing data until all data has been read from the file
    try:
        while(True):
            frames = wav_fh.readframes(n_bytes // 2)
            print('read {} bytes'.format(len(frames)))
            if not frames:
                break

            stream.write(frames)
            time.sleep(.1)
    finally:
        # stop recognition and clean up
        wav_fh.close()
        stream.close()
    print('EXIT send_voice_frame')


def speech_recognition_with_push_stream(stream):
    print('ENTER speech_recognition_with_push_stream')
    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)

    # setup the audio stream
    audio_config = speechsdk.audio.AudioConfig(stream=stream)

    # instantiate the speech recognizer with push stream input
    speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)
    recognition_done = threading.Event()

    # Connect callbacks to the events fired by the speech recognizer
    def stop_cb(evt):
        """callback that signals to stop continuous recognition upon receiving an event `evt`"""
        print('SESSION STOPPED {}'.format(evt))
        recognition_done.set()

    speech_recognizer.recognizing.connect(lambda evt: print('RECOGNIZING: {}'.format(evt)))
    speech_recognizer.recognized.connect(lambda evt: print('RECOGNIZED: {}'.format(evt)))
    speech_recognizer.session_started.connect(lambda evt: print('SESSION STARTED: {}'.format(evt)))
    speech_recognizer.session_stopped.connect(stop_cb)
    speech_recognizer.canceled.connect(lambda evt: print('CANCELED {}'.format(evt)))

    # start continuous speech recognition
    speech_recognizer.start_continuous_recognition()

    # wait until input processed
    recognition_done.wait()

    # stop continuous speech recognition
    speech_recognizer.stop_continuous_recognition()
    print('EXIT speech_recognition_with_push_stream')


if __name__ == '__main__':
    stream = speechsdk.audio.PushAudioInputStream()
    # threads
    thread1 = threading.Thread(target=speech_recognition_with_push_stream, args=[stream])
    thread1.start()
    thread2 = threading.Thread(target=send_voice_frame, args=[stream])
    thread2.start()
